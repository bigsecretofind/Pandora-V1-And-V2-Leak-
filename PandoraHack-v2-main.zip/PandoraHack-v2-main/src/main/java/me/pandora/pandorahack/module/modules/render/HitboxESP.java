package me.pandora.pandorahack.module.modules.render;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.RenderEvent;
import me.pandora.pandorahack.friends.Friends;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.util.PandoraTessellator;
import me.pandora.pandorahack.util.Rainbow;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.EntityPlayer;

import java.awt.*;

public class HitboxESP extends Module {
    public HitboxESP() {
        super("HitboxESP", Category.RENDER);
        PandoraMod.getInstance().settingsManager.rSetting(players = new Setting("Players", this, false, "HitBoxEspPlayers"));
        PandoraMod.getInstance().settingsManager.rSetting(passive = new Setting("Passive", this, false, "HitBoxEspPassive"));
        PandoraMod.getInstance().settingsManager.rSetting(mobs = new Setting("Mobs", this, false, "HitBoxEspMobs"));
        PandoraMod.getInstance().settingsManager.rSetting(exp = new Setting("XpBottles", this, false, "HitBoxEspXpBottles"));
        rSetting(orbs = new Setting("XpOrbs", this, false, "HitBoxEspXpOrbs"));
        PandoraMod.getInstance().settingsManager.rSetting(epearls = new Setting("Epearls", this, false, "HitBoxEspEpearls"));
        PandoraMod.getInstance().settingsManager.rSetting(crystals = new Setting("Crystals", this, false, "HitBoxEspCrystals"));
        PandoraMod.getInstance().settingsManager.rSetting(items = new Setting("Items", this, false, "HitBoxEspItems"));
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "HitBoxEspRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(r = new Setting("Red", this, 255, 1, 255, true, "HitBoxEspRed"));
        PandoraMod.getInstance().settingsManager.rSetting(g = new Setting("Green", this, 255, 1, 255, true, "HitBoxEspGreen"));
        PandoraMod.getInstance().settingsManager.rSetting(b = new Setting("Blue", this, 255, 1, 255, true, "HitBoxEspBlue"));
        PandoraMod.getInstance().settingsManager.rSetting(a = new Setting("Alpha", this, 50, 1, 255, true, "HitBoxEspAlpha"));
    }

    Setting players;
    Setting passive;
    Setting mobs;
    Setting exp;
    Setting epearls;
    Setting crystals;
    Setting items;
    Setting orbs;

    Setting rainbow;
    Setting r;
    Setting g;
    Setting b;
    Setting a;
    Color c;

    public void onWorldRender(RenderEvent event){
        c = new Color(r.getValInt(), g.getValInt(), b.getValInt(), a.getValInt());
        if(rainbow.getValBoolean()) c = new Color(Rainbow.getColor().getRed(), Rainbow.getColor().getGreen(), Rainbow.getColor().getBlue(), a.getValInt());
        Color enemy = new Color(255, 0, 0, a.getValInt());
        Color friend = new Color(0, 255, 255, a.getValInt());
        mc.world.loadedEntityList.stream()
                .filter(entity -> entity != mc.player)
                .forEach(e -> {
                    PandoraTessellator.prepareGL();
                    if(players.getValBoolean() && e instanceof EntityPlayer) {
                        if (Friends.isFriend(e.getName())) PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, friend.getRGB());
                        else PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, enemy.getRGB());
                    }
                    if(mobs.getValBoolean() && GlowESP.isMonster(e)){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(passive.getValBoolean() && GlowESP.isPassive(e)){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(exp.getValBoolean() && e instanceof EntityExpBottle){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(epearls.getValBoolean() && e instanceof EntityEnderPearl){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(crystals.getValBoolean() && e instanceof EntityEnderCrystal){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(items.getValBoolean() && e instanceof EntityItem){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    if(orbs.getValBoolean() && e instanceof EntityXPOrb){
                        PandoraTessellator.drawBoundingBox(e.getRenderBoundingBox(), 1, c.getRGB());
                    }
                    PandoraTessellator.releaseGL();
                });
    }
}
