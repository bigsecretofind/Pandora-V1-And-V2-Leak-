package me.pandora.pandorahack.module.modules.render;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.RenderEvent;
import me.pandora.pandorahack.friends.Friends;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.util.GeometryMasks;
import me.pandora.pandorahack.util.PandoraTessellator;
import me.pandora.pandorahack.util.Rainbow;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class BoxESP extends Module {
    public BoxESP() {
        super("BoxESP", Category.RENDER, "Draws a box around entities");
        PandoraMod.getInstance().settingsManager.rSetting(players = new Setting("Players", this, false, "BoxEspPlayers"));
        PandoraMod.getInstance().settingsManager.rSetting(passive = new Setting("Passive", this, false, "BoxEspPassive"));
        PandoraMod.getInstance().settingsManager.rSetting(mobs = new Setting("Mobs", this, false, "BoxEspMobs"));
        PandoraMod.getInstance().settingsManager.rSetting(exp = new Setting("XpBottles", this, false, "BoxEspXpBottles"));
        PandoraMod.getInstance().settingsManager.rSetting(epearls = new Setting("Epearls", this, false, "BoxEspEpearls"));
        PandoraMod.getInstance().settingsManager.rSetting(crystals = new Setting("Crystals", this, false, "BoxEspCrystals"));
        PandoraMod.getInstance().settingsManager.rSetting(items = new Setting("Items", this, false, "BoxEspItems"));
        rSetting(orbs = new Setting("XpOrbs", this, false, "BoxEspXpOrbs"));
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "BoxEspRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(r = new Setting("Red", this, 255, 1, 255, true, "BoxEspRed"));
        PandoraMod.getInstance().settingsManager.rSetting(g = new Setting("Green", this, 255, 1, 255, true, "BoxEspGreen"));
        PandoraMod.getInstance().settingsManager.rSetting(b = new Setting("Blue", this, 255, 1, 255, true, "BoxEspBlue"));
        PandoraMod.getInstance().settingsManager.rSetting(a = new Setting("Alpha", this, 50, 1, 255, true, "BoxEspAlpha"));
    }

    Setting players;
    Setting passive;
    Setting mobs;
    Setting exp;
    Setting epearls;
    Setting crystals;
    Setting items;
    Setting orbs;

    Setting rainbow;
    Setting r;
    Setting g;
    Setting b;
    Setting a;

    public void onWorldRender(RenderEvent event){
        Color c = new Color(r.getValInt(), g.getValInt(), b.getValInt(), a.getValInt());
        if(rainbow.getValBoolean()) c = new Color(Rainbow.getColor().getRed(), Rainbow.getColor().getGreen(), Rainbow.getColor().getBlue(), a.getValInt());
        Color enemy = new Color(255, 0, 0, a.getValInt());
        Color friend = new Color(0, 255, 255, a.getValInt());
        Color finalC = c;
        mc.world.loadedEntityList.stream()
                .filter(entity -> entity != mc.player)
                .forEach(e -> {
                    PandoraTessellator.prepare(GL11.GL_QUADS);
                    if(players.getValBoolean() && e instanceof EntityPlayer) {
                        if (Friends.isFriend(e.getName())) PandoraTessellator.drawBox(e.getRenderBoundingBox(), friend.getRGB(), GeometryMasks.Quad.ALL);
                        else PandoraTessellator.drawBox(e.getRenderBoundingBox(), enemy.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(mobs.getValBoolean() && GlowESP.isMonster(e)){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(passive.getValBoolean() && GlowESP.isPassive(e)){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(exp.getValBoolean() && e instanceof EntityExpBottle){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(epearls.getValBoolean() && e instanceof EntityEnderPearl){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(crystals.getValBoolean() && e instanceof EntityEnderCrystal){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(items.getValBoolean() && e instanceof EntityItem){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    if(orbs.getValBoolean() && e instanceof EntityXPOrb){
                        PandoraTessellator.drawBox(e.getRenderBoundingBox(), finalC.getRGB(), GeometryMasks.Quad.ALL);
                    }
                    PandoraTessellator.release();
                });
    }
}
