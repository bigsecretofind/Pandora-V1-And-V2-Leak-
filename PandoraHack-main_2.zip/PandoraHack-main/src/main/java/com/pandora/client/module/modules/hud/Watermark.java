package com.pandora.client.module.modules.hud;

import java.awt.Point;

import com.pandora.api.settings.Setting;
import com.pandora.api.util.render.PandoraColor;
import com.pandora.client.PandoraMod;
import com.pandora.client.clickgui.PandoraGUI;
import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.hud.HUDComponent;

// PanelStudio rewrite by lukflug
public class Watermark extends HUDModule {
	private static Setting.ColorSetting color;
	
	public Watermark() {
		super(new WatermarkComponent(),new Point(0,0));
	}
	
	public void setup() {
		color=registerColor("Color", "Color", new PandoraColor(255, 0, 0, 255));
	}

	private static class WatermarkComponent extends HUDComponent {
		public WatermarkComponent() {
			super("Watermark", PandoraGUI.theme.getPanelRenderer(),new Point(0,0));
		}
		
		private String getString() {
			return "Pandora "+ PandoraMod.MODVER;
		}
		
		@Override
		public void render (Context context) {
			super.render(context);
			context.getInterface().drawString(context.getPos(),getString(),color.getValue());
		}

		@Override
		public int getWidth (Interface inter) {
			return inter.getFontWidth(getString());
		}

		@Override
		public void getHeight (Context context) {
			context.setHeight(renderer.getHeight());
		}
	}
}
