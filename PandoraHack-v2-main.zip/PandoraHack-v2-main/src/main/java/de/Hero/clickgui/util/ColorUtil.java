package de.Hero.clickgui.util;

import java.awt.Color;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.util.Rainbow;

/**
 *  Made by HeroCode
 *  it's free to use
 *  but you have to credit me
 *
 *  @author HeroCode
 */
public class ColorUtil {
	
	public static Color getClickGUIColor(){
		if(PandoraMod.getInstance().settingsManager.getSettingByID("ClickGuiRainbow").getValBoolean())
			return Rainbow.getColor();
		else
			return new Color((int) PandoraMod.getInstance().settingsManager.getSettingByID("ClickGuiRed").getValDouble(), (int) PandoraMod.getInstance().settingsManager.getSettingByID("ClickGuiGreen").getValDouble(), (int) PandoraMod.getInstance().settingsManager.getSettingByID("ClickGuiBlue").getValDouble());
	}
}
