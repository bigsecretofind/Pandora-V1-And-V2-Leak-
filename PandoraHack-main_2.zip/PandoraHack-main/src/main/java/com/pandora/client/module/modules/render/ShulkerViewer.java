package com.pandora.client.module.modules.render;

import com.pandora.client.module.Module;

/**
 * Pandora epic shulker preview... I hope :D
 * Check com.Pandora.api.mixin.mixins.MixinGuiScreen
 */

public class ShulkerViewer extends Module{
	public ShulkerViewer(){
		super("ShulkerViewer", Category.Render);
	}
}