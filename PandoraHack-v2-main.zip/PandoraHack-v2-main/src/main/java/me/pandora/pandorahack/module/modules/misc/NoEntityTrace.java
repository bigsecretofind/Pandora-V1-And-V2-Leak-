package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.module.Module;

public class NoEntityTrace extends Module {
    public NoEntityTrace() {
        super("NoEntityTrace", Category.MISC);
    }
}
