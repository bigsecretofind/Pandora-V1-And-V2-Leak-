package com.pandora.client.module.modules.misc;

import com.pandora.api.event.events.DamageBlockEvent;
import com.pandora.api.settings.Setting;
import com.pandora.client.PandoraMod;
import com.pandora.client.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Mouse;

public class AutoTool extends Module{
	public AutoTool(){
		super("AutoTool", Category.Misc);
	}

	Setting.Boolean switchBack;


	boolean shouldMoveBack = false;
	int lastSlot = 0;
	long lastChange = 0L;

	public void setup(){
		switchBack = registerBoolean("Switch Back", "SwitchBack", false);
	}

	@EventHandler
	private final Listener<DamageBlockEvent> leftClickListener = new Listener<>(event -> {
		equipBestTool(mc.world.getBlockState(event.getPos()));
	});

	public void onUpdate(){

		if (!switchBack.getValue())
			shouldMoveBack = false;

		if (mc.currentScreen != null || !switchBack.getValue()) return;

		boolean mouse = Mouse.isButtonDown(0);
		if (mouse && !shouldMoveBack){
			lastChange = System.currentTimeMillis();
			shouldMoveBack = true;
			lastSlot = mc.player.inventory.currentItem;
			mc.playerController.syncCurrentPlayItem();
		} else if (!mouse && shouldMoveBack){
			shouldMoveBack = false;
			mc.player.inventory.currentItem = lastSlot;
			mc.playerController.syncCurrentPlayItem();
		}

	}



	private void equipBestTool(IBlockState blockState){
		int bestSlot = -1;
		double max = 0;
		for (int i = 0; i < 9; i++){
			ItemStack stack = mc.player.inventory.getStackInSlot(i);
			if (stack.isEmpty()) continue;
			float speed = stack.getDestroySpeed(blockState);
			int eff;
			if (speed > 1){
				speed += ((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0 ? (Math.pow(eff, 2) + 1) : 0);
				if (speed > max){
					max = speed;
					bestSlot = i;
				}
			}
		}
		if (bestSlot != -1) equip(bestSlot);
	}


	private static void equip(int slot){
		mc.player.inventory.currentItem = slot;
		mc.playerController.syncCurrentPlayItem();
	}


	public void onEnable(){
		PandoraMod.EVENT_BUS.subscribe(this);
	}

	public void onDisable(){
		PandoraMod.EVENT_BUS.unsubscribe(this);
	}
}
