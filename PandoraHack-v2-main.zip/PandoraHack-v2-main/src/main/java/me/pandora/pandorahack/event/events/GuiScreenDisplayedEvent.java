package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;
import net.minecraft.client.gui.GuiScreen;

public class GuiScreenDisplayedEvent extends PandoraEvent {
    private final GuiScreen guiScreen;
    public GuiScreenDisplayedEvent(GuiScreen screen){
        super();
        guiScreen = screen;
    }

    public GuiScreen getScreen(){
        return guiScreen;
    }

}
