package com.pandora.client.module.modules.movement;

import com.pandora.api.event.events.JumpEvent;
import com.pandora.api.settings.Setting;
import com.pandora.api.util.world.MotionUtils;
import com.pandora.client.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class Sprint extends Module {

	public Sprint(){
		super("Sprint", Category.Movement);
	}

	Setting.Boolean reverseSprint;

	public void setup(){
		reverseSprint = registerBoolean("Reverse", "Reverse", false);
	}

	public void onUpdate(){
		if (mc.player == null){
			return;
		}

		if (mc.gameSettings.keyBindSneak.isKeyDown()){
			mc.player.setSprinting(false);
			return;
		}
		else if (mc.player.getFoodStats().getFoodLevel() > 6 && reverseSprint.getValue()? (mc.player.moveForward != 0 || mc.player.moveStrafing != 0):mc.player.moveForward > 0){
			mc.player.setSprinting(true);
		}
	}

	@EventHandler
	private final Listener<JumpEvent> jumpEventListener = new Listener<>(event -> {
		if (reverseSprint.getValue()){
			double[] direction = MotionUtils.forward(0.017453292F);
			event.getLocation().setX(direction[0] * 0.2F);
			event.getLocation().setZ(direction[1] * 0.2F);
		}
	});
}