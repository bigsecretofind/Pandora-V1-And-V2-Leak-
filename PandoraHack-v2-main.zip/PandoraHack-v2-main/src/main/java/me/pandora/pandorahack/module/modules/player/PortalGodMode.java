package me.pandora.pandorahack.module.modules.player;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.PacketEvent;
import me.pandora.pandorahack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketConfirmTeleport;

public class PortalGodMode extends Module {
    public PortalGodMode() {
        super("PortalGodmode", Category.PLAYER, "Godmode when you go through a portal");
    }

    public void onEnable() {
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable() {
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }

    @EventHandler
    private Listener<PacketEvent.Send> listener = new Listener<>(event -> {
        if(event.getPacket() instanceof CPacketConfirmTeleport)
            event.cancel();
    });
}
