package me.pandora.pandorahack.module.modules.chat;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.event.events.PlayerJoinEvent;
import me.pandora.pandorahack.event.events.PlayerLeaveEvent;
import me.pandora.pandorahack.module.Module;

import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;

public class Welcomer extends Module {
    public Welcomer() {
        super("Welcomer", Category.CHAT, "Sends a message when someone joins the server");
        PandoraMod.getInstance().settingsManager.rSetting(publicS = new Setting("Public", this, false, "WelcomerPublicMode"));
    }
    Setting publicS;

    @EventHandler
    private Listener<PlayerJoinEvent> listener1 = new Listener<>(event -> {
        if(publicS.getValBoolean()) mc.player.sendChatMessage(event.getName() + " joined the game");
        else Command.sendClientMessage(event.getName() + " joined the game");
    });

    @EventHandler
    private Listener<PlayerLeaveEvent> listener2 = new Listener<>(event -> {
        if(publicS.getValBoolean()) mc.player.sendChatMessage(event.getName() + " left the game");
        else Command.sendClientMessage(event.getName() + " left the game");
    });

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }
}
