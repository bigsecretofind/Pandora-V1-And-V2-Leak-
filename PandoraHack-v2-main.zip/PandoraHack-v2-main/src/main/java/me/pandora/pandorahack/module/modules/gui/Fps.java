package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;

import java.awt.*;

public class Fps extends Module {
    public Fps() {
        super("FPS", Category.GUI);
        setDrawn(false);
    }
    public Setting rainbow;
    public Setting customFont;
    public Setting color;

    public void setup(){
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "FpsRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "FpsCustomFont"));
        rSetting(color = new Setting("Color", this, Color.WHITE, "FpsColor"));
    }

    public void onEnable(){
        disable();
    }
}
