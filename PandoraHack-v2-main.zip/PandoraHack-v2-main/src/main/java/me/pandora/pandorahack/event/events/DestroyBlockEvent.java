package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;
import net.minecraft.util.math.BlockPos;

public class DestroyBlockEvent extends PandoraEvent {
    BlockPos pos;
    public DestroyBlockEvent(BlockPos blockPos){
        super();
        pos = blockPos;
    }

    public BlockPos getBlockPos(){
        return pos;
    }
}
