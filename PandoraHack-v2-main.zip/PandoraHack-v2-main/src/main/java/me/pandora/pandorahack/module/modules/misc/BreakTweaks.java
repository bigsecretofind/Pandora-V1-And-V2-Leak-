package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.module.Module;

public class BreakTweaks extends Module {
    public BreakTweaks() {
        super("BreakTweaks", Category.MISC, "Tweaks block breaking");
    }
}
