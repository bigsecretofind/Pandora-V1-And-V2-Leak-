package me.pandora.pandorahack.module.modules.render;

import me.pandora.pandorahack.module.Module;

public class CameraClip extends Module {
    public CameraClip() {
        super("CameraClip", Category.RENDER, "makes the third person camera clip through blocks");
    }
}
