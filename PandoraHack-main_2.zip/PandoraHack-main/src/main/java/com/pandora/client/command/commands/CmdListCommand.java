package com.pandora.client.command.commands;

import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.command.Command;
import com.pandora.client.command.CommandManager;

/**
 * @Author Hoosiers on 11/05/2020
 */

public class CmdListCommand extends Command {

    public CmdListCommand(){
        super("Commands");

        setCommandSyntax(Command.getCommandPrefix() + "commands");
        setCommandAlias(new String[]{
                "commands", "cmd", "command", "commandlist"
        });
    }

    public void onCommand(String command, String[] message) throws Exception{
        for (Command command1 : CommandManager.getCommands()){
            MessageBus.sendClientPrefixMessage(command1.getCommandName() + ": " + "\"" + command1.getCommandSyntax() + "\"!");
        }
    }
}