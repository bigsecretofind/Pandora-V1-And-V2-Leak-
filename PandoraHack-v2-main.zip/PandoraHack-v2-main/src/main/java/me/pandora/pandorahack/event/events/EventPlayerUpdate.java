package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;

public class EventPlayerUpdate extends PandoraEvent {}