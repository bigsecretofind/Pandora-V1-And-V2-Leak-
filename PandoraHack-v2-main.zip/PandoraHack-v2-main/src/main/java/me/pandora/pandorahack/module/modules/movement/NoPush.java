package me.pandora.pandorahack.module.modules.movement;

import me.pandora.pandorahack.module.Module;

public class NoPush extends Module {
    public NoPush() {
        super("NoPush", Category.MOVEMENT, "Don't get pushed by entities");
    }
}
