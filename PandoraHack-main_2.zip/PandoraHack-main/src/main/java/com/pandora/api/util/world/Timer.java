package com.pandora.api.util.world;

public class Timer{
	private long current;

	private long time;

	public Timer(){
		this.current = System.currentTimeMillis();
	}

	public boolean hasReached(final long delay){
		return System.currentTimeMillis() - this.current >= delay;
	}

	public boolean hasReached(final long delay, boolean reset){
		if (reset)
			reset();
		return System.currentTimeMillis() - this.current >= delay;
	}

	public long getMs(final long time) {
		return time / 1000000L;
	}

	public void reset(){
		this.current = System.currentTimeMillis();
	}

	public long getTimePassed(){
		return System.currentTimeMillis() - this.current;
	}

	public boolean passedMs(final long ms) {
		return this.getMs(System.nanoTime() - this.time()) >= ms;
	}


	public boolean sleep(final long time){
		if (time() >= time){
			reset();
			return true;
		}
		return false;
	}

	public long time(){
		return System.currentTimeMillis() - current;
	}
}


