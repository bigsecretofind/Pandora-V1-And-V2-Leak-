package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;

import java.util.ArrayList;

public class Coords extends Module {
    public Coords() {
        super("Coordinates", Category.GUI);
        setDrawn(false);
    }

    public Setting red;
    public Setting green;
    public Setting blue;
    public Setting rainbow;
    public Setting customFont;
    public Setting decimal;

    public void setup(){
        ArrayList<String> modes = new ArrayList<>();
        modes.add("0");
        modes.add("0.0");
        modes.add("0.00");
        modes.add("0.0#");
        red = new Setting("Red", this, 255, 0, 255, true, "CoordinatesRed");
        green = new Setting("Green", this, 255, 0, 255, true, "CoordinatesGreen");
        blue = new Setting("Blue", this, 255, 0, 255, true, "CoordinatesBlue");
        PandoraMod.getInstance().settingsManager.rSetting(red);
        PandoraMod.getInstance().settingsManager.rSetting(green);
        PandoraMod.getInstance().settingsManager.rSetting(blue);
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "CoordinatesRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "CoordinatesCustomFont"));
        PandoraMod.getInstance().settingsManager.rSetting(decimal = new Setting("DecimalFormat", this, "0", modes, "CoordinatesDecimalFormat"));
    }

    public void onEnable(){
        disable();
    }
}
