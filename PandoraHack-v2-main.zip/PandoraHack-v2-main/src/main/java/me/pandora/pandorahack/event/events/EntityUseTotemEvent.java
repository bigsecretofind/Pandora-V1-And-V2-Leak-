package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;
import net.minecraft.entity.Entity;

public class EntityUseTotemEvent extends PandoraEvent {
    private Entity entity;

    public EntityUseTotemEvent(Entity entity) {
        super();
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }
}