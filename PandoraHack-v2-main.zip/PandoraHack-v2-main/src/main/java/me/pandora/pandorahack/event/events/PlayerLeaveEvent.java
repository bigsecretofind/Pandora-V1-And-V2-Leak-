package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;
public class PlayerLeaveEvent extends PandoraEvent {

    private final String name;

    public PlayerLeaveEvent(String n){
        super();
        name = n;
    }

    public String getName(){
        return name;
    }


}
