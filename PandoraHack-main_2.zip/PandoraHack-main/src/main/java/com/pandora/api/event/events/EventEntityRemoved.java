package com.pandora.api.event.events;

import com.pandora.api.event.PandoraEvent;
import net.minecraft.entity.Entity;

public class EventEntityRemoved extends PandoraEvent {
	private final Entity entity;

    public EventEntityRemoved(Entity entity) {
        this.entity = entity;
    }

    public Entity get_entity() {
        return this.entity;
    }
}