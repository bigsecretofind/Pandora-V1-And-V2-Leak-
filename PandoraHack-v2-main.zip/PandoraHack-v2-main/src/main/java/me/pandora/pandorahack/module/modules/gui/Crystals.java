package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;
import java.util.ArrayList;

public class Crystals extends Module {
    public Crystals() {
        super("Crystals", Category.GUI);
        setDrawn(false);
    }

    public Setting red;
    public Setting green;
    public Setting blue;
    public Setting rainbow;
    public Setting customFont;
    public Setting mode;

    public void setup(){
        ArrayList<String> modes = new ArrayList<>();
        modes.add("Short");
        modes.add("Full");
        modes.add("Item");
        red = new Setting("Red", this, 255, 0, 255, true, "CrystalsRed");
        green = new Setting("Green", this, 255, 0, 255, true, "CrystalsGreen");
        blue = new Setting("Blue", this, 255, 0, 255, true, "CrystalsBlue");
        PandoraMod.getInstance().settingsManager.rSetting(red);
        PandoraMod.getInstance().settingsManager.rSetting(green);
        PandoraMod.getInstance().settingsManager.rSetting(blue);
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "CrystalsRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "CrystalsCustomFont"));
        PandoraMod.getInstance().settingsManager.rSetting(mode = new Setting("Mode", this, "Short", modes, "CrystalsMode"));
    }

    public void onEnable(){
        disable();
    }
}
