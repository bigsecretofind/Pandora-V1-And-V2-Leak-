package com.pandora.api.event.events;

import com.pandora.api.event.PandoraEvent;

public class PlayerJumpEvent extends PandoraEvent {

	public PlayerJumpEvent(){
		super();
	}
}
