package com.pandora.api.util.font;

import com.pandora.api.util.render.PandoraColor;
import com.pandora.client.PandoraMod;
import net.minecraft.client.Minecraft;

public class FontUtils {
	private static final Minecraft mc = Minecraft.getMinecraft();
	
	public static float drawStringWithShadow(boolean customFont, String text, int x, int y, PandoraColor color){
		if(customFont) return PandoraMod.fontRenderer.drawStringWithShadow(text, x, y, color);
		else return mc.fontRenderer.drawStringWithShadow(text, x, y, color.getRGB());
	}

	public static int getStringWidth(boolean customFont, String str){
		if (customFont) return PandoraMod.fontRenderer.getStringWidth(str);
		else return mc.fontRenderer.getStringWidth(str);
	}

	public static int getFontHeight(boolean customFont){
		if (customFont) return PandoraMod.fontRenderer.getHeight();
		else return mc.fontRenderer.FONT_HEIGHT;
	}
}