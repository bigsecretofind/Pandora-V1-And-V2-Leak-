package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.util.snake.Board;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class SnakeModule extends Module {
    public SnakeModule() {
        super("Snake", Category.MISC, "Play snake");
    }

    public void onEnable(){
        EventQueue.invokeLater(() -> {
            JFrame ex = new Snake();
            ex.setVisible(true);
        });
        disable();
    }

    public class Snake extends JFrame {

        public Snake() {

            initUI();
        }

        private void initUI() {

            add(new Board());

            setResizable(false);
            pack();

            setTitle("Pandora Snake");
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }
    }
}
