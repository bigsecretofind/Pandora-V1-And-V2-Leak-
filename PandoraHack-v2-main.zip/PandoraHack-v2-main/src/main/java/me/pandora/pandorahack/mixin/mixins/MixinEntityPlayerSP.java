package me.pandora.pandorahack.mixin.mixins;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.PandoraEvent;
import me.pandora.pandorahack.event.events.EventPlayerMotionUpdate;
import me.pandora.pandorahack.event.events.EventPlayerUpdate;
import me.pandora.pandorahack.event.events.PlayerMoveEvent;
import me.pandora.pandorahack.util.PandoraTessellator;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.MoverType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer {
    public MixinEntityPlayerSP() {
        super(null, null);
    }

    @Redirect(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/AbstractClientPlayer;move(Lnet/minecraft/entity/MoverType;DDD)V"))
    public void move(AbstractClientPlayer player, MoverType type, double x, double y, double z) {
        PlayerMoveEvent moveEvent = new PlayerMoveEvent(type, x, y, z);
        PandoraMod.EVENT_BUS.post(moveEvent);
        if(moveEvent.isCancelled()) {
        }
        super.move(type, moveEvent.x, moveEvent.y, moveEvent.z);
    }

    @Inject(method = {"onUpdate"}, at = {@At("HEAD")}, cancellable = true)
    public void onUpdate(CallbackInfo p_Info) {
        EventPlayerUpdate l_Event = new EventPlayerUpdate();
        PandoraMod.EVENT_BUS.post(l_Event);
        if (l_Event.isCancelled())
            p_Info.cancel();
    }

    @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("HEAD")}, cancellable = true)
    public void OnPreUpdateWalkingPlayer(CallbackInfo p_Info) {
        EventPlayerMotionUpdate l_Event = new EventPlayerMotionUpdate(PandoraEvent.Era.PRE);
        PandoraMod.EVENT_BUS.post(l_Event);
        if (l_Event.isCancelled())
            p_Info.cancel();
    }

    @Inject(method = {"onUpdateWalkingPlayer"}, at = {@At("RETURN")}, cancellable = true)
    public void OnPostUpdateWalkingPlayer(CallbackInfo p_Info) {
        EventPlayerMotionUpdate l_Event = new EventPlayerMotionUpdate(PandoraEvent.Era.POST);
        PandoraMod.EVENT_BUS.post(l_Event);
        if (l_Event.isCancelled())
            p_Info.cancel();
    }
}

