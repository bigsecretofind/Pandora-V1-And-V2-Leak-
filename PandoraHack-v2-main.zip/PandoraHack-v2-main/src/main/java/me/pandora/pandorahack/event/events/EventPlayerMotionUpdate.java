package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;

public class EventPlayerMotionUpdate extends PandoraEvent {
  public EventPlayerMotionUpdate(PandoraEvent.Era p_Era) {}
}
