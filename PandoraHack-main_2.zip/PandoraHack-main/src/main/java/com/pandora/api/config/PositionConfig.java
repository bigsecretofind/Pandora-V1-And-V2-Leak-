package com.pandora.api.config;

import java.awt.Point;

public interface PositionConfig {
	public Point getConfigPos();
	public void setConfigPos (Point pos);
}
