package com.pandora.client.module.modules.hud;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

import com.pandora.api.settings.Setting;
import com.pandora.api.util.render.PandoraColor;
import com.pandora.client.clickgui.PandoraGUI;
import com.lukflug.panelstudio.Context;
import com.lukflug.panelstudio.Interface;
import com.lukflug.panelstudio.hud.HUDComponent;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;

// PanelStudio rewrite by lukflug
public class InventoryViewer extends HUDModule {
	private static Setting.ColorSetting fillColor;
    private static Setting.ColorSetting outlineColor;
    
    public InventoryViewer() {
    	super(new InventoryViewerComponent(),new Point(0,10));
    }

    public void setup() {
        fillColor = registerColor("Fill", "Fill", new PandoraColor(0, 0, 0, 100));
        outlineColor = registerColor("Outline", "Outline", new PandoraColor(255, 0, 0, 255));
    }
    
    
    private static class InventoryViewerComponent extends HUDComponent {
		public InventoryViewerComponent() {
			super("InventoryViewer", PandoraGUI.theme.getPanelRenderer(),new Point(0,10));
		}
		
		@Override
		public void render (Context context) {
			super.render(context);
			// Render background
			Color bgcolor=new PandoraColor(fillColor.getValue(),100);
			context.getInterface().fillRect(context.getRect(),bgcolor,bgcolor,bgcolor,bgcolor);
			// Render outline
			Color color=outlineColor.getValue();
			context.getInterface().fillRect(new Rectangle(context.getPos(),new Dimension(context.getSize().width,1)),color,color,color,color);
			context.getInterface().fillRect(new Rectangle(context.getPos(),new Dimension(1,context.getSize().height)),color,color,color,color);
			context.getInterface().fillRect(new Rectangle(new Point(context.getPos().x+context.getSize().width-1,context.getPos().y),new Dimension(1,context.getSize().height)),color,color,color,color);
			context.getInterface().fillRect(new Rectangle(new Point(context.getPos().x,context.getPos().y+context.getSize().height-1),new Dimension(context.getSize().width,1)),color,color,color,color);
			// Render the actual items
	        NonNullList<ItemStack> items = Minecraft.getMinecraft().player.inventory.mainInventory;
	        for (int size = items.size(), item = 9; item < size; ++item) {
	            int slotX = context.getPos().x + item % 9 * 18;
	            int slotY = context.getPos().y + 2 + (item / 9 - 1) * 18;
				PandoraGUI.renderItem(items.get(item),new Point(slotX,slotY));
	        }
		}

		@Override
		public int getWidth (Interface inter) {
			return 162;
		}

		@Override
		public void getHeight (Context context) {
			context.setHeight(56);
		}
	}
}