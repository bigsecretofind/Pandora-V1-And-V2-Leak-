package com.pandora.api.util.players.enemy;

public class Enemy{

	String name;
	public Enemy(String n){
		name = n;
	}

	public String getName(){
		return name;
	}
}
