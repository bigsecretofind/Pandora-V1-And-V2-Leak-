package me.pandora.pandorahack.command.commands;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import org.lwjgl.opengl.Display;

public class ClientnameCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{
                "name", "modname", "clientname", "suffix", "watermark"
        };
    }

    @Override
    public String getSyntax() {
        return "name <new name>";
    }

    @Override
    public void onCommand(String command, String[] args) throws Exception {
        if(!args[0].replace("__", " ").equalsIgnoreCase("")) {
            PandoraMod.MODNAME = args[0].replace("__", " ");
            Display.setTitle(PandoraMod.MODNAME + " " + PandoraMod.MODVER);
            sendClientMessage("set client name to " + args[0].replace("__", " "));
        }else
            sendClientMessage(getSyntax());
    }
}
