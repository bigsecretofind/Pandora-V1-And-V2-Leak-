package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;

public class Time extends Module {
    public Time() {
        super("Time", Category.GUI);
        setDrawn(false);
    }

    public Setting red;
    public Setting green;
    public Setting blue;
    public Setting rainbow;
    public Setting customFont;

    public void setup(){
        red = new Setting("Red", this, 255, 0, 255, true, "TimeRed");
        green = new Setting("Green", this, 255, 0, 255, true, "TimeGreen");
        blue = new Setting("Blue", this, 255, 0, 255, true, "TimeBlue");
        PandoraMod.getInstance().settingsManager.rSetting(red);
        PandoraMod.getInstance().settingsManager.rSetting(green);
        PandoraMod.getInstance().settingsManager.rSetting(blue);
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "TimeRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "TimeCustomFont"));
    }

    public void onEnable(){
        disable();
    }
}
