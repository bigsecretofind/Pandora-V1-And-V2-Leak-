package com.pandora.client.module.modules.misc;

import com.pandora.api.util.misc.Discord;
import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.module.Module;

public class DiscordRPCModule extends Module {
    public DiscordRPCModule(){
        super("DiscordRPC", Category.Misc);
        setDrawn(false);
    }

    public void onEnable(){
        Discord.startRPC();
        if (mc.player != null || mc.world != null){
            MessageBus.sendClientPrefixMessage("Discord RPC started!");
        }
    }

    public void onDisable(){
        Discord.stopRPC();
        if (mc.player != null || mc.world != null) {
            MessageBus.sendClientPrefixMessage("Discord RPC stopped!");
        }
    }
}