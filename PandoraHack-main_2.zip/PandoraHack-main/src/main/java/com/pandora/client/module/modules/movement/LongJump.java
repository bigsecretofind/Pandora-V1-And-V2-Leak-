package com.pandora.client.module.modules.movement;

import com.pandora.api.settings.Setting;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;
import net.minecraft.network.play.client.*;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(Side.CLIENT)
public class LongJump extends Module {
    public LongJump() {
        super("LongJump", Category.Movement);
    }

    private static boolean jumped = false;
    private static boolean boostable = false;

    Setting.Integer speed;
    Setting.Boolean packet;
    Setting.Boolean test;

    public void setup(){
        speed = registerInteger("Speed","Speed",30,1,100);
        packet = registerBoolean("Packet","Packet",true);
        test = registerBoolean("Test","test",true);
    }

    public void onUpdate(){
        if (mc.player == null || mc.world == null) return;

        if (jumped)
        {
            if (mc.player.onGround || mc.player.capabilities.isFlying)
            {
                jumped = false;

                mc.player.motionX = 0.0;
                mc.player.motionZ = 0.0;

                if (packet.getValue())
                {
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, mc.player.onGround));
                    mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX + mc.player.motionX, 0.0, mc.player.posZ + mc.player.motionZ, mc.player.onGround));
                }

                disable();
                return;
            }

            if (!(mc.player.movementInput.moveForward != 0f || mc.player.movementInput.moveStrafe != 0f)) return;
            double yaw = getDirection();
            mc.player.motionX = -Math.sin(yaw) * (((float) Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ)) * (boostable ? (speed.getValue() / 10f) : 1f));
            mc.player.motionZ = Math.cos(yaw) * (((float) Math.sqrt(mc.player.motionX * mc.player.motionX + mc.player.motionZ * mc.player.motionZ)) * (boostable ? (speed.getValue() / 10f) : 1f));

            if (test.getValue()) {
                new Thread(()-> {
                    try {
                        Thread.sleep(200);
                        mc.player.rotationPitch = -9.5F;
                        mc.player.setActiveHand(EnumHand.MAIN_HAND);
                        while (mc.player.getItemInUseMaxCount() < 3) {/* waiting */}
                        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
                        mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(mc.player.getActiveHand()));
                        mc.player.stopActiveHand();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }).start();
            }

            boostable = false;
            disable();
        }

        if (!(mc.player.movementInput.moveForward != 0f || mc.player.movementInput.moveStrafe != 0f) && jumped)
        {
            mc.player.motionX = 0.0;
            mc.player.motionZ = 0.0;
        }
    }

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        if (!ModuleManager.getModuleByName("LongJump").isEnabled()) return;

        if ((mc.player != null && mc.world != null) && event.getEntity() == mc.player && (mc.player.movementInput.moveForward != 0f || mc.player.movementInput.moveStrafe != 0f))
        {
            jumped = true;
            boostable = true;
        }
    }

    private double getDirection()
    {
        float rotationYaw = mc.player.rotationYaw;

        if (mc.player.moveForward < 0f) rotationYaw += 180f;

        float forward = 1f;

        if (mc.player.moveForward < 0f) forward = -0.5f;
        else if (mc.player.moveForward > 0f) forward = 0.5f;

        if (mc.player.moveStrafing > 0f) rotationYaw -= 90f * forward;
        if (mc.player.moveStrafing < 0f) rotationYaw += 90f * forward;

        return Math.toRadians(rotationYaw);
    }
}