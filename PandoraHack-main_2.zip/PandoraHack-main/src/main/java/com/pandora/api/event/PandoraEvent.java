package com.pandora.api.event;

import me.zero.alpine.type.Cancellable;

public class PandoraEvent extends Cancellable{

	public PandoraEvent(){
	}
}
