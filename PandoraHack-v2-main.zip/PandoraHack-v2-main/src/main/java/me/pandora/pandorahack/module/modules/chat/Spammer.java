package me.pandora.pandorahack.module.modules.chat;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.module.Module;

import java.util.ArrayList;
import java.util.List;

public class Spammer extends Module {
    public Spammer() {
        super("Spammer", Category.CHAT);
        text = new ArrayList<>();
    }

    public static List<String> text;
    int waitCounter;
    Setting delay;
    int i = -1;

    public void setup(){
        PandoraMod.getInstance().settingsManager.rSetting(delay = new Setting("Delay", this, 5, 1, 100, true, "SpammerDelay"));
    }

    public void onUpdate(){
        if(text.size() <= 0 || text.isEmpty()){
            Command.sendClientMessage("Spammer list empty, disabling");
            disable();
        }
        if (waitCounter < delay.getValDouble() * 100) {
            waitCounter++;
            return;
        } else {
            waitCounter = 0;
        }
        i++;
        if(!(i + 1 > text.size()))
            mc.player.sendChatMessage(text.get(i));
        else
            i = -1;

    }
}
