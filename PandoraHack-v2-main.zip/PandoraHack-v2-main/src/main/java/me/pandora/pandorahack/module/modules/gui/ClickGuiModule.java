package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.module.ModuleManager;
import me.pandora.pandorahack.module.modules.chat.Announcer;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;

public class ClickGuiModule extends Module {
    public ClickGuiModule INSTANCE;
    public ClickGuiModule() {
        super("ClickGUI", Category.GUI, "Opens the ClickGUI");
        setBind(Keyboard.KEY_P);
        INSTANCE = this;
    }

    public void setup(){
        ArrayList<String> options = new ArrayList<>();
        options.add("New");
        options.add("rhack");
        options.add("Old");
        options.add("JellyLike");
        options.add("f0nzi");
        options.add("Windows");
        PandoraMod.getInstance().settingsManager.rSetting(new Setting("Design", this, "Old", options, "ClickGuiDesign"));
        PandoraMod.getInstance().settingsManager.rSetting(new Setting("Rainbow", this, false, "ClickGuiRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(new Setting("Red", this, 255, 0, 255, true, "ClickGuiRed"));
        PandoraMod.getInstance().settingsManager.rSetting(new Setting("Green", this, 26, 0, 255, true, "ClickGuiGreen"));
        PandoraMod.getInstance().settingsManager.rSetting(new Setting("Blue", this, 42, 0, 255, true, "ClickGuiBlue"));
        rSetting(new Setting("Tooltips", this, true, "ClickGuiTooltips"));
    }

    public void onEnable(){
        mc.displayGuiScreen(PandoraMod.getInstance().clickGui);
        if(((Announcer)ModuleManager.getModuleByName("Announcer")).clickGui.getValBoolean() && ModuleManager.isModuleEnabled("Announcer") && mc.player != null)
            if(((Announcer)ModuleManager.getModuleByName("Announcer")).clientSide.getValBoolean()){
                Command.sendClientMessage(Announcer.guiMessage);
            } else {
                mc.player.sendChatMessage(Announcer.guiMessage);
            }
        disable();
    }
}
