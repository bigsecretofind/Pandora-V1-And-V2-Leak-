//Never gonna give you up
package me.pandora.pandorahack;
//Never gonna let you down
public class BitcoinMiner {
//Never gonna run around
}
//and desert you