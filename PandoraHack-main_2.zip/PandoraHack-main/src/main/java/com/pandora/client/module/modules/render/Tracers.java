package com.pandora.client.module.modules.render;

import java.util.ArrayList;

import com.pandora.api.event.events.RenderEvent;
import com.pandora.api.util.players.enemy.Enemies;
import com.pandora.api.util.players.friends.Friends;
import com.pandora.api.settings.Setting;
import com.pandora.api.util.render.PandoraColor;
import com.pandora.api.util.render.PandoraTessellator;
import com.pandora.client.module.Module;
import com.pandora.client.module.modules.gui.ColorMain;

import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

/**
 * Made by Hoosiers on 8/12/20, some GL from Osiris/KAMI was referenced.
 */

public class Tracers extends Module {
	public Tracers(){
		super("Tracers", Category.Render);
	}

	Setting.Integer renderDistance;
	Setting.Mode pointsTo;
	Setting.ColorSetting nearColor;
	Setting.ColorSetting midColor;
	Setting.ColorSetting farColor;

	public void setup(){
		renderDistance = registerInteger("Distance", "Distance", 100, 10, 260);

		ArrayList<String> link = new ArrayList<>();
		link.add("Head");
		link.add("Feet");

		pointsTo = registerMode("Draw To", "DrawTo", link, "Feet");
		nearColor=registerColor("Near Color","NearColor",new PandoraColor(255,0,0, 255));
		midColor=registerColor("Middle Color","MidColor",new PandoraColor(255,255,0, 255));
		farColor=registerColor("Far Color","FarColor",new PandoraColor(0,255,0, 255));
	}

	PandoraColor tracerColor;

	public void onWorldRender(RenderEvent event){
		mc.world.loadedEntityList.stream()
				.filter(e->e instanceof EntityPlayer)
				.filter(e->e != mc.player)
				.forEach(e->{
					if (mc.player.getDistance(e) > renderDistance.getValue()){
						return;
					} else {
						if (Friends.isFriend(e.getName())) {
							tracerColor = ColorMain.getFriendGSColor();
						} else if (Enemies.isEnemy(e.getName())) {
							tracerColor = ColorMain.getEnemyGSColor();
						} else {
							if (mc.player.getDistance(e) < 20) {
								tracerColor = nearColor.getValue();
							}
							if (mc.player.getDistance(e) >= 20 && mc.player.getDistance(e) < 50) {
								tracerColor = midColor.getValue();
							}
							if (mc.player.getDistance(e) >= 50) {
								tracerColor = farColor.getValue();
							}
						}
					}
					GlStateManager.pushMatrix();
					drawLineToEntityPlayer(e, tracerColor);
					GlStateManager.popMatrix();
				});
	}

	public void drawLineToEntityPlayer(Entity e, PandoraColor color){
		double[] xyz = interpolate(e);
		drawLine1(xyz[0],xyz[1],xyz[2], e.height, color);
	}

	public static double[] interpolate(Entity entity) {
		double posX = interpolate(entity.posX, entity.lastTickPosX);
		double posY = interpolate(entity.posY, entity.lastTickPosY);
		double posZ = interpolate(entity.posZ, entity.lastTickPosZ);
		return new double[] { posX, posY, posZ };
	}

	public static double interpolate(double now, double then) {
		return then + (now - then) * mc.getRenderPartialTicks();
	}

	public void drawLine1(double posx, double posy, double posz, double up, PandoraColor color){
		Vec3d eyes=ActiveRenderInfo.getCameraPosition().add(mc.getRenderManager().viewerPosX,mc.getRenderManager().viewerPosY,mc.getRenderManager().viewerPosZ);
		if (pointsTo.getValue().equalsIgnoreCase("Head")) {
			PandoraTessellator.drawLine(eyes.x, eyes.y, eyes.z, posx, posy+up, posz, color);
		} else {
			PandoraTessellator.drawLine(eyes.x, eyes.y, eyes.z, posx, posy, posz, color);
		}
	}
}
