package com.pandora.client.module.modules.misc;

import com.pandora.client.module.Module;

public class MultiTask extends Module{
	public MultiTask(){super("MultiTask", Category.Misc);}

}
