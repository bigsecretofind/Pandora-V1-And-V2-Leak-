package me.pandora.pandorahack.module.modules.chat;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.event.events.PacketEvent;
import me.pandora.pandorahack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;

public class UwuChat extends Module  {
    public UwuChat() {
        super("UwuChat", Category.CHAT, "uwu");
    }

    @EventHandler
    private Listener<PacketEvent.Send> packetSendListener = new Listener<>(event -> {
        if(event.getPacket() instanceof CPacketChatMessage){
            if(((CPacketChatMessage) event.getPacket()).getMessage().startsWith("/") || ((CPacketChatMessage) event.getPacket()).getMessage().startsWith(Command.getPrefix())) return;
            String old = ((CPacketChatMessage) event.getPacket()).getMessage();
            String s = old.replace("r", "w").replace("R", "W").replace("ll", "ww").replace("LL", "WW") + " uwu";
            if(s.length() > 255) return;
            ((CPacketChatMessage) event.getPacket()).message = s;
        }
    });

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }
}
