package me.pandora.pandorahack.enemy;

public class Enemy {
    String name;
    public Enemy(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}
