package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;

public class Ping extends Module {
    public Ping() {
        super("Ping", Category.GUI);
        setDrawn(false);
    }

    public Setting red;
    public Setting green;
    public Setting blue;
    public Setting rainbow;
    public Setting customFont;

    public void setup(){
        red = new Setting("Red", this, 255, 0, 255, true, "PingRed");
        green = new Setting("Green", this, 255, 0, 255, true, "PingGreen");
        blue = new Setting("Blue", this, 255, 0, 255, true, "PingBlue");
        PandoraMod.getInstance().settingsManager.rSetting(red);
        PandoraMod.getInstance().settingsManager.rSetting(green);
        PandoraMod.getInstance().settingsManager.rSetting(blue);
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "PingRainbow"));
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "PingCustomFont"));
    }

    public int getPing(){
        int p = -1;
        if(mc.player == null || mc.getConnection() == null || mc.getConnection().getPlayerInfo(mc.player.getName()) == null){
            p = -1;
        } else {
            p = mc.getConnection().getPlayerInfo(mc.player.getName()).getResponseTime();
        }
        return p;
    }

    public void onEnable(){
        disable();
    }
}
