package com.pandora.client.module.modules.gui;

import com.pandora.api.settings.Setting;
import com.pandora.api.util.render.PandoraColor;
import com.pandora.client.PandoraMod;
import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;
import com.pandora.client.module.modules.misc.Announcer;
import net.minecraft.util.ResourceLocation;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

public class ClickGuiModule extends Module{
	public ClickGuiModule INSTANCE;
	public ClickGuiModule(){
		super("ClickGUI", Category.GUI);
		setBind(Keyboard.KEY_O);
		setDrawn(false);
		INSTANCE = this;
	}

	public static Setting.Integer scrollSpeed;
	public static Setting.Integer opacity;
	public static Setting.ColorSetting enabledColor;
	public static Setting.ColorSetting outlineColor;
	public static Setting.ColorSetting backgroundColor;
	public static Setting.ColorSetting settingBackgroundColor;
	public static Setting.ColorSetting fontColor;
	public static Setting.Integer animationSpeed;
	Setting.Boolean backgroundBlur;
	public static Setting.Mode scrolling;
	public static Setting.Boolean showHUD;

	public void setup(){
		backgroundBlur = registerBoolean("Blur", "Blur", false);
		opacity = registerInteger("Opacity", "Opacity", 150,50,255);
		scrollSpeed = registerInteger("Scroll Speed", "ScrollSpeed", 10, 1, 20);
		outlineColor = registerColor("Outline", "Outline", new PandoraColor(255, 0, 0, 255));
		enabledColor =registerColor("Enabled","Enabled", new PandoraColor(255, 0, 0, 255));
		backgroundColor = registerColor("Background", "Background", new PandoraColor(0, 0, 0, 255));
		settingBackgroundColor = registerColor("Setting", "Setting", new PandoraColor(30, 30, 30, 255));
		fontColor = registerColor("Font", "Font", new PandoraColor(255, 255, 255 ,255));
		animationSpeed = registerInteger("Animation Speed", "AnimationSpeed", 200, 0, 1000);
		ArrayList<String> models=new ArrayList<>();
		models.add("Screen");
		models.add("Container");
		scrolling=registerMode("Scrolling","ScrollingMode",models,"Screen");
		showHUD=registerBoolean("Show HUD Panels","ShowHUD",true);
	}

	/** This uses minecraft's old "super secret" shaders, which means it could be modified to be a bunch of things in the future */
	private ResourceLocation shader = new ResourceLocation("minecraft", "shaders/post/blur" + ".json");

	public void onEnable(){
		mc.displayGuiScreen(PandoraMod.getInstance().clickGUI);
		if (!PandoraMod.getInstance().clickGUI.gui.isOn()) PandoraMod.getInstance().clickGUI.gui.toggle();

		if (backgroundBlur.getValue()) {
			mc.entityRenderer.loadShader(shader);
		}

		if(((Announcer) ModuleManager.getModuleByName("Announcer")).clickGui.getValue() && ModuleManager.isModuleEnabled("Announcer") && mc.player != null) {
			if (((Announcer) ModuleManager.getModuleByName("Announcer")).clientSide.getValue()) {
				MessageBus.sendClientPrefixMessage(Announcer.guiMessage);
			}
			else {
				MessageBus.sendServerMessage(Announcer.guiMessage);
			}
		}
	}

	public void onUpdate(){
		if (backgroundBlur.getValue() && !mc.entityRenderer.isShaderActive()){
			mc.entityRenderer.loadShader(shader);
		}

		if (!backgroundBlur.getValue() && mc.entityRenderer.isShaderActive()){
			mc.entityRenderer.stopUseShader();
		}

		if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)){
			this.disable();
		}
	}

	public void onDisable(){
		if (mc.entityRenderer.isShaderActive()) {
			mc.entityRenderer.stopUseShader();
		}
	}
}