package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.PacketEvent;
import me.pandora.pandorahack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.network.play.client.*;

public class XCarry extends Module {
    public XCarry() {
        super("XCarry", Category.MISC, "lets you carry items in your crafting slots");
    }

    @EventHandler
    private Listener<PacketEvent.Send> listener = new Listener<>(event -> {
        if(event.getPacket() instanceof CPacketCloseWindow){
            if(((CPacketCloseWindow)event.getPacket()).windowId == mc.player.inventoryContainer.windowId){
                event.cancel();
            }
        }
    });

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }
}
