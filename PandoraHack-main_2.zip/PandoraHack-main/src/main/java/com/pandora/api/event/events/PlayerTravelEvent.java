package com.pandora.api.event.events;

import com.pandora.api.event.PandoraEvent;

public class PlayerTravelEvent extends PandoraEvent {
}
