package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.GuiScreenDisplayedEvent;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.waypoint.Waypoint;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.GuiGameOver;

import java.awt.*;

public class DeathWaypoint extends Module {
    public DeathWaypoint() {
        super("DeathWaypoint", Category.MISC, "Makes a waypoint where you die");
    }

    @EventHandler
    private Listener<GuiScreenDisplayedEvent> listener = new Listener<>(event -> {
        if (event.getScreen() instanceof GuiGameOver) {
            PandoraMod.getInstance().waypointManager.delWaypoint( PandoraMod.getInstance().waypointManager.getWaypointByName("Last Death"));
            PandoraMod.getInstance().waypointManager.addWaypoint(new Waypoint("Last Death", mc.player.posX, mc.player.posY, mc.player.posZ, Color.RED.getRGB()));
        }
    });

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }

}
