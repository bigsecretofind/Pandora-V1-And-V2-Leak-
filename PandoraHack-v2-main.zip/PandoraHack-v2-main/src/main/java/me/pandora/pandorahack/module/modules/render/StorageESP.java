package me.pandora.pandorahack.module.modules.render;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.RenderEvent;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.util.PandoraTessellator;
import net.minecraft.tileentity.*;

import java.awt.*;
import java.util.concurrent.ConcurrentHashMap;

public class StorageESP extends Module {
    public StorageESP() {
        super("StorageESP", Category.RENDER, "Highlight chests and stuff");
    }

    Setting a;
    Setting w;

    ConcurrentHashMap<TileEntity, String> chests = new ConcurrentHashMap<>();

    public void setup(){
        a = new Setting("Alpha", this, 150, 0, 255, true, "StorageESPAlpha");
        PandoraMod.getInstance().settingsManager.rSetting(a);
        w = new Setting("Width", this, 1, 1, 10, true, "StorageESPWidth");
        PandoraMod.getInstance().settingsManager.rSetting(w);
    }

    public void onUpdate(){
        mc.world.loadedTileEntityList.forEach(e->{
                chests.put(e, "");
        });
    }

    public void onWorldRender(RenderEvent event){
        Color c1 = new Color(200, 100, 0, (int)a.getValDouble());
        Color c2 = new Color(200, 0, 200, (int)a.getValDouble());
        Color c3 = new Color(150, 150, 150, (int)a.getValDouble());
        if(chests != null && chests.size() > 0){
            PandoraTessellator.prepareGL();
            chests.forEach((c, t)->{
                if(mc.world.loadedTileEntityList.contains(c)) {
                    if(c instanceof TileEntityChest
                            || c instanceof TileEntityShulkerBox)
                        //PandoraTessellator.drawBox(c.getPos(), c1.getRGB(), GeometryMasks.Quad.ALL);
                        PandoraTessellator.drawBoundingBox(mc.world.getBlockState(c.getPos()).getSelectedBoundingBox(mc.world, c.getPos()), (float)w.getValDouble(), c1.getRGB());
                    if(c instanceof TileEntityEnderChest)
                        //PandoraTessellator.drawBox(c.getPos(), c2.getRGB(), GeometryMasks.Quad.ALL);
                        PandoraTessellator.drawBoundingBox(mc.world.getBlockState(c.getPos()).getSelectedBoundingBox(mc.world, c.getPos()), (float)w.getValDouble(), c2.getRGB());
                    if(c instanceof TileEntityDispenser
                            || c instanceof TileEntityFurnace
                            || c instanceof TileEntityHopper)
                    //PandoraTessellator.drawBox(c.getPos(), c3.getRGB(), GeometryMasks.Quad.ALL);
                        PandoraTessellator.drawBoundingBox(mc.world.getBlockState(c.getPos()).getSelectedBoundingBox(mc.world, c.getPos()), (float)w.getValDouble(), c3.getRGB());
                }
            });
            PandoraTessellator.releaseGL();
        }
    }
}
