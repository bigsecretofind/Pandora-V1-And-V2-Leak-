package me.pandora.pandorahack;

public class ShutDownHookerino extends Thread {
    @Override
    public void run(){
        saveConfig();
    }

    public static void saveConfig(){
        PandoraMod.getInstance().configUtils.saveMods();
        PandoraMod.getInstance().configUtils.saveSettingsList();
        PandoraMod.getInstance().configUtils.saveBinds();
        PandoraMod.getInstance().configUtils.saveDrawn();
        PandoraMod.getInstance().configUtils.saveFriends();
        PandoraMod.getInstance().configUtils.saveGui();
        PandoraMod.getInstance().configUtils.savePrefix();
        PandoraMod.getInstance().configUtils.saveRainbow();
        PandoraMod.getInstance().configUtils.saveMacros();
        PandoraMod.getInstance().configUtils.saveMsgs();
        PandoraMod.getInstance().configUtils.saveAutoGG();
        PandoraMod.getInstance().configUtils.saveSpammer();
        PandoraMod.getInstance().configUtils.saveAutoReply();
        PandoraMod.getInstance().configUtils.saveAnnouncer();
        PandoraMod.getInstance().configUtils.saveWaypoints();
        PandoraMod.getInstance().configUtils.saveHudComponents();
        PandoraMod.getInstance().configUtils.saveFont();
        PandoraMod.getInstance().configUtils.saveEnemies();
        PandoraMod.getInstance().configUtils.saveClientname();
    }
}
