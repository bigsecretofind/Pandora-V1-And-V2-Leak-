package me.pandora.pandorahack.module.modules.gui;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;

public class Bps extends Module {
    public Bps() {
        super("BPS", Category.GUI);
        setDrawn(false);
    }

    public Setting red;
    public Setting green;
    public Setting blue;
    public Setting rainbow;
    public Setting customFont;

    public void setup(){
        red = new Setting("Red", this, 255, 0, 255, true, "BlocksPerSecondRed");
        green = new Setting("Green", this, 255, 0, 255, true, "BlocksPerSecondGreen");
        blue = new Setting("Blue", this, 255, 0, 255, true, "BlocksPerSecondBlue");
        PandoraMod.getInstance().settingsManager.rSetting(red);
        PandoraMod.getInstance().settingsManager.rSetting(green);
        PandoraMod.getInstance().settingsManager.rSetting(blue);
        rainbow = new Setting("Rainbow", this, false, "BlocksPerSecondRaiknbow");
        PandoraMod.getInstance().settingsManager.rSetting(rainbow);
        PandoraMod.getInstance().settingsManager.rSetting(customFont = new Setting("CFont", this, false, "BlocksPerSecondCustomFont"));
    }

    public void onEnable(){
        disable();
    }


}
