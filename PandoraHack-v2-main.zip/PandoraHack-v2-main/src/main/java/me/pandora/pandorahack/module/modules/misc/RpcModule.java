package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.PandoraDiscordRPC;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.module.Module;

public class RpcModule extends Module {
    public RpcModule() {
        super("DiscordRPC", Category.MISC, "Discord Rich Presence");
        setDrawn(false);
    }

    public void onEnable(){
        PandoraDiscordRPC.init();
        if(mc.player != null)
            Command.sendClientMessage("discord rpc started");
    }

    public void onDisable(){
        Command.sendClientMessage("you need to restart your game disable rpc");
    }
}
