package com.pandora.client.module;

import java.awt.Point;
import java.util.ArrayList;
import java.util.stream.Collectors;
import org.lwjgl.input.Keyboard;

import com.pandora.client.module.modules.combat.*;
import com.pandora.client.module.modules.movement.*;
import com.pandora.client.module.modules.render.*;
import com.pandora.client.module.modules.hud.*;
import com.pandora.client.module.modules.misc.*;
import com.pandora.client.module.modules.gui.*;
import com.pandora.client.module.modules.exploits.*;

import com.pandora.api.event.events.RenderEvent;
import com.pandora.api.util.render.PandoraTessellator;
import com.pandora.client.PandoraMod;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;

public class ModuleManager {
	public static ArrayList<Module> modules;

	public ModuleManager(){
		modules = new ArrayList<>();
		//Combat
		addMod(new AutoArmor());
		addMod(new Auto32K());
		addMod(new Aura2());
		addMod(new AutoCrystal());
		addMod(new AutoCrystal2());
		addMod(new AutoTotem());
		addMod(new AutoTrap());
		addMod(new AutoWeb());
		addMod(new BedAura());
		addMod(new FastBow());
		addMod(new HoleFill());
		addMod(new KillAura());
		addMod(new OffhandCrystal());
		addMod(new OffhandGap());
		addMod(new Quiver());
		addMod(new SelfTrap());
		addMod(new SelfWeb());
		addMod(new Surround());
		//Exploits
		addMod(new CoordExploit());
		addMod(new FastBreak());
		addMod(new MountBypass());
		addMod(new LiquidInteract());
		addMod(new NoInteract());
		addMod(new NoSwing());
		//addMod(new PacketXP());
		addMod(new PortalGodMode());
		//Movement
		addMod(new Anchor());
		addMod(new Blink());
		addMod(new HoleTP());
		addMod(new NoSlow());
		addMod(new LongJump());
		addMod(new PlayerTweaks());
		addMod(new ReverseStep());
		addMod(new Scaffold());
		addMod(new Strafe());
		addMod(new Speed());
		addMod(new Sprint());
		addMod(new Step());
		addMod(new Velocity());
		//Misc
		addMod(new Announcer());
		addMod(new AutoGG());
		addMod(new AutoReply());
		addMod(new AutoTool());
		addMod(new ChatModifier());
		addMod(new ChatSuffix());
		addMod(new HuaweiSuffix());
		addMod(new DiscordRPCModule());
		addMod(new FastPlace());
		addMod(new FakePlayer());
		addMod(new HoosiersDupe());
		addMod(new HotbarRefill());
		addMod(new MCF());
		addMod(new MultiTask());
		addMod(new NoEntityTrace());
		addMod(new NoKick());
		addMod(new PvPInfo());
		//Render
		addMod(new BlockHighlight());
		addMod(new CapesModule());
		addMod(new CityESP());
		addMod(new ESP());
		addMod(new Freecam());
		addMod(new Fullbright());
		addMod(new HitSpheres());
		addMod(new HoleESP());
		addMod(new LogoutSpots());
		addMod(new Nametags());
		addMod(new NoRender());
		addMod(new RenderTweaks());
		addMod(new ShulkerViewer());
		addMod(new SkyColor());
		addMod(new Tracers());
		addMod(new ViewModel());
		addMod(new VoidESP());
		//HUD
		addMod(new ArmorHUD());
		addMod(new ModuleArrayList());
		addMod(new CombatInfo());
		addMod(new InventoryViewer());
		addMod(new Notifications());
		addMod(new PotionEffects());
		addMod(new HUDModule(new TabGUIModule(),new Point(10,10)));
		addMod(new TargetHUD());
		addMod(new TextRadar());
		addMod(new Watermark());
		addMod(new Welcomer());
		//GUI
		addMod(new ClickGuiModule());
		addMod(new ColorMain());
	}

	public static void addMod(Module m){
		modules.add(m);
	}

	public static void onUpdate() {
		modules.stream().filter(Module::isEnabled).forEach(Module::onUpdate);
	}

	public static void onRender() {
		modules.stream().filter(Module::isEnabled).forEach(Module::onRender);
		PandoraMod.getInstance().clickGUI.render();
	}

	public static void onWorldRender(RenderWorldLastEvent event) {
		Minecraft.getMinecraft().profiler.startSection("pandora");
		Minecraft.getMinecraft().profiler.startSection("setup");
		PandoraTessellator.prepare();
		RenderEvent e = new RenderEvent(event.getPartialTicks());
		Minecraft.getMinecraft().profiler.endSection();

		modules.stream().filter(module -> module.isEnabled()).forEach(module -> {
			Minecraft.getMinecraft().profiler.startSection(module.getName());
			module.onWorldRender(e);
			Minecraft.getMinecraft().profiler.endSection();
		});

		Minecraft.getMinecraft().profiler.startSection("release");
		PandoraTessellator.release();
		Minecraft.getMinecraft().profiler.endSection();
		Minecraft.getMinecraft().profiler.endSection();
	}

	public static ArrayList<Module> getModules() {
		return modules;
	}

	public static ArrayList<Module> getModulesInCategory(Module.Category c){
		ArrayList<Module> list = (ArrayList<Module>) getModules().stream().filter(m -> m.getCategory().equals(c)).collect(Collectors.toList());
		return list;
	}

	public static void onBind(int key) {
		if (key == 0 || key == Keyboard.KEY_NONE) return;
		modules.forEach(module -> {
			if(module.getBind() == key){
				module.toggle();
			}
		});
	}

	public static Module getModuleByName(String name){
		Module m = getModules().stream().filter(mm->mm.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
		return m;
	}

	public static boolean isModuleEnabled(String name){
		Module m = getModules().stream().filter(mm->mm.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
		return m.isEnabled();
	}

	public static boolean isModuleEnabled(Module m){
		return m.isEnabled();
	}

	public static Vec3d getInterpolatedPos(Entity entity, float ticks) {
		return new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ).add(getInterpolatedAmount(entity, ticks));
	}

	public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
		return getInterpolatedAmount(entity, ticks, ticks, ticks);
	}

	public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
		return new Vec3d(
				(entity.posX - entity.lastTickPosX) * x,
				(entity.posY - entity.lastTickPosY) * y,
				(entity.posZ - entity.lastTickPosZ) * z
		);
	}
}