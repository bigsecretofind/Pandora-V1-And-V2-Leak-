package me.pandora.pandorahack.module.modules.chat;

import me.pandora.pandorahack.module.Module;

import java.util.Random;

public class KettuLinuxDupe extends Module {
    public KettuLinuxDupe() {
        super("KettuLinuxDupe", Category.CHAT);
    }

    public void onEnable(){
        if(mc.player != null)
            mc.player.sendChatMessage("I just used the Kettu Linux Dupe and got " + new Random().nextInt(15) + " shulkers! Powered PandoraHack+\u2122");
        disable();
    }
}
