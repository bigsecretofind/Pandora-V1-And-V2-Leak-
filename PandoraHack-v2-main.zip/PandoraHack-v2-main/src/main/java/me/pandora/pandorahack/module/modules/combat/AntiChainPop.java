package me.pandora.pandorahack.module.modules.combat;

import me.pandora.pandorahack.module.Module;

public class AntiChainPop extends Module {
    public AntiChainPop() {
        super("AntiChainPop", Category.COMBAT);
    }

}
