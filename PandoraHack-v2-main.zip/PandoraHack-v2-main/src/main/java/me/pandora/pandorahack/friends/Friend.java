package me.pandora.pandorahack.friends;

public class Friend {
    String name;
    public Friend(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}
