package me.pandora.pandorahack.module.modules.player;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.PacketEvent;
import me.pandora.pandorahack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.server.SPacketAnimation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;

public class PacketGap extends Module {
    public PacketGap() {
        super("PacketGap", Category.PLAYER, "take a wild guess");
    }

    @EventHandler
    private final Listener<PacketEvent.Send> sendListener = new Listener<>(event -> {

    });

    @EventHandler
    private final Listener<PacketEvent.Receive> receiveListener = new Listener<>(event -> {
        if (event.getPacket() instanceof SPacketAnimation) {
            SPacketAnimation pak = (SPacketAnimation) event.getPacket();
            if (pak.getEntityID() != mc.player.getEntityId()) return;
            event.cancel();
        }
    });

    @Override
    public void setup() {

    }

    @Override
    public void onEnable(){
        mc.playerController.windowClick(0, mc.player.inventory.currentItem+36, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);

        CPacketPlayerTryUseItem packet = new CPacketPlayerTryUseItem(EnumHand.OFF_HAND);
        mc.player.connection.sendPacket(packet);

        mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, mc.player.inventory.currentItem+36, 0, ClickType.PICKUP, mc.player);

        PandoraMod.EVENT_BUS.subscribe(this);
    }

    @Override
    protected void onDisable() {
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }

    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(mc.player.posX), Math.floor(mc.player.posY), Math.floor(mc.player.posZ));
    }
}