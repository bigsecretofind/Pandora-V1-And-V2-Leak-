package me.pandora.pandorahack.util;

import java.lang.reflect.Field;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class Wrapper {
	private static Wrapper theWrapper = new Wrapper();
	public static Minecraft mc = Minecraft.getMinecraft();
	public static FontRenderer fr = Minecraft.getMinecraft().fontRenderer;
	public static Block getBlock(BlockPos pos) {
			return Minecraft.getMinecraft().world.getBlockState(pos).getBlock();
		}
	    public static Minecraft getMinecraft() {
	        return Minecraft.getMinecraft();
	    }
	    public static EntityPlayerSP getPlayer() {
	        return getMinecraft().player;
	    }
	    public static World getWorld() {
	        return getMinecraft().world;
	    }
	    public static <T, E> void setPrivateValue(Class<? super T> classToAccess, T instance, E value, String... fieldNames)
	    {
	      try
	      {
	        findField(classToAccess, fieldNames).set(instance, value);
	      }
	      catch (Exception e) {}
	    }
		  private static Field findField(Class<?> clazz, String... fieldNames)
		  {
		    Exception failed = null;
		    for (String fieldName : fieldNames) {
		      try {
		        Field f = clazz.getDeclaredField(fieldName);
		        f.setAccessible(true);
		        return f;
		      } catch (Exception e) {
		        failed = e;
		      }
		    }
		    return null;
		  }

}