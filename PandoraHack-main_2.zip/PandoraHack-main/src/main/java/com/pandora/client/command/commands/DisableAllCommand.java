package com.pandora.client.command.commands;

import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.command.Command;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;

/**
 * @Author Hoosiers on 11/05/2020
 */

public class DisableAllCommand extends Command {

    public DisableAllCommand(){
        super("DisableAll");

        setCommandSyntax(Command.getCommandPrefix() + "disableall");
        setCommandAlias(new String[]{
                "disableall", "stop"
        });
    }

    public void onCommand(String command, String[] message) throws Exception{
        int count = 0;

        for (Module module : ModuleManager.getModules()){
            if (module.isEnabled()){
                module.disable();
                count++;
            }
        }

        MessageBus.sendClientPrefixMessage("Disabled " + count + " modules!");
    }
}