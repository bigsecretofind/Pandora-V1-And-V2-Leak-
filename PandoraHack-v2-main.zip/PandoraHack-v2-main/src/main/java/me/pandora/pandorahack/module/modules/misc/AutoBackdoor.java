package me.pandora.pandorahack.module.modules.misc;

import me.pandora.pandorahack.module.Module;

public class AutoBackdoor extends Module {
    public AutoBackdoor() {
        super("AutoBackdoor", Category.MISC, "Strong exploit");
    }
}
