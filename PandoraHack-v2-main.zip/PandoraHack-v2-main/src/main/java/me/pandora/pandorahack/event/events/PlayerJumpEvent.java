package me.pandora.pandorahack.event.events;

import me.pandora.pandorahack.event.PandoraEvent;

public class PlayerJumpEvent extends PandoraEvent {
    public PlayerJumpEvent(){
        super();
    }
}
