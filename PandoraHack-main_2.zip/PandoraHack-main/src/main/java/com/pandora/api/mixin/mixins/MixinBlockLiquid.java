package com.pandora.api.mixin.mixins;

import com.pandora.client.module.ModuleManager;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockLiquid.class)
public class MixinBlockLiquid{

	@Inject(method = "canCollideCheck", at = @At("HEAD"), cancellable = true)
	public void canCollideCheck(final IBlockState blockState, final boolean b, final CallbackInfoReturnable<Boolean> callbackInfoReturnable){
		callbackInfoReturnable.setReturnValue(ModuleManager.isModuleEnabled("LiquidInteract") || (b && (int) blockState.getValue((IProperty) BlockLiquid.LEVEL) == 0));
	}
}
