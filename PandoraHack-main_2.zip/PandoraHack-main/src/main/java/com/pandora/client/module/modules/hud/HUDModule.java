package com.pandora.client.module.modules.hud;

import java.awt.Point;

import com.pandora.client.PandoraMod;
import com.pandora.client.module.Module;
import com.lukflug.panelstudio.FixedComponent;

/**
 * @author lukflug
 */
public class HUDModule extends Module {
	protected final FixedComponent component;
	protected final Point position;
	
	public HUDModule (FixedComponent component, Point defaultPos) {
		super(component.getTitle(),Category.HUD);
		this.component=component;
		this.position=defaultPos;
	}

	public FixedComponent getComponent() {
		return component;
	}
	
	public void resetPosition() {
		component.setPosition(PandoraMod.getInstance().clickGUI,position);
	}
}
