package me.pandora.pandorahack.module.modules.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;

public class MiddleClickFriends extends Module {
    public MiddleClickFriends() {
        super("MCF", Category.MISC, "Middle click players to add / remove them as a friend");
    }

    @EventHandler
    private Listener<InputEvent.MouseInputEvent> listener = new Listener<>(event -> {
        if (mc.objectMouseOver.typeOfHit.equals(RayTraceResult.Type.ENTITY) && mc.objectMouseOver.entityHit instanceof EntityPlayer && Mouse.getEventButton() == 2) {
            if (PandoraMod.getInstance().friends.isFriend(mc.objectMouseOver.entityHit.getName())) {
                PandoraMod.getInstance().friends.delFriend(mc.objectMouseOver.entityHit.getName());
                Command.sendClientMessage(ChatFormatting.RED + "Removed " + mc.objectMouseOver.entityHit.getName() + " from friends list");
            } else {
                PandoraMod.getInstance().friends.addFriend(mc.objectMouseOver.entityHit.getName());
                Command.sendClientMessage(ChatFormatting.GREEN + "Added " + mc.objectMouseOver.entityHit.getName() + " to friends list");
            }
        }
    });

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }
}
