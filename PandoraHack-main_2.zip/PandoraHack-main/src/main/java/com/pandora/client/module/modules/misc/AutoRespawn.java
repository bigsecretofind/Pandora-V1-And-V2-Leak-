package com.pandora.client.module.modules.misc;

import com.pandora.api.event.events.GuiScreenDisplayedEvent;
import com.pandora.api.settings.Setting;
import com.pandora.client.PandoraMod;
import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.module.Module;
import me.zero.alpine.listener.EventHandler;
import me.zero.alpine.listener.Listener;
import net.minecraft.client.gui.GuiGameOver;

public class AutoRespawn extends Module{
	public AutoRespawn(){
		super("AutoRespawn", Category.Misc);
	}

	Setting.Boolean coords;

	public void setup(){
		coords = registerBoolean("Coords", "Coords", false);
	}

	@EventHandler
	private final Listener<GuiScreenDisplayedEvent> listener = new Listener<>(event -> {
		if (event.getScreen() instanceof GuiGameOver){
			if (coords.getValue())
				MessageBus.sendClientPrefixMessage(String.format("You died at x%d y%d z%d", (int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ));
			if (mc.player != null)
				mc.player.respawnPlayer();
			mc.displayGuiScreen(null);
		}
	});

	public void onEnable(){
		PandoraMod.EVENT_BUS.subscribe(this);
	}

	public void onDisable(){
		PandoraMod.EVENT_BUS.unsubscribe(this);
	}
}