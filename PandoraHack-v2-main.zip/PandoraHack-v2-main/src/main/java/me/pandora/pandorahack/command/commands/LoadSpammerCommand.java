package me.pandora.pandorahack.command.commands;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.command.Command;
import me.pandora.pandorahack.module.modules.chat.Spammer;

public class LoadSpammerCommand extends Command {
    @Override
    public String[] getAlias() {
        return new String[]{"loadspammer"};
    }

    @Override
    public String getSyntax() {
        return "loadspammer";
    }

    @Override
    public void onCommand(String command, String[] args) throws Exception {
        Spammer.text.clear();
        PandoraMod.getInstance().configUtils.loadSpammer();
        Command.sendClientMessage("Loaded Spammer File");
    }
}
