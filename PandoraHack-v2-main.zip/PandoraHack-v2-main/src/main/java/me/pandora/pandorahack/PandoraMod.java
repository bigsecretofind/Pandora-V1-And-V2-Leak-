package me.pandora.pandorahack;

import de.Hero.clickgui.ClickGUI;
import me.pandora.pandorahack.enemy.Enemies;
import me.pandora.pandorahack.hud.HudComponentManager;
import de.Hero.settings.SettingsManager;
import me.pandora.pandorahack.command.CommandManager;
import me.pandora.pandorahack.event.EventProcessor;
import me.pandora.pandorahack.macro.MacroManager;
import me.pandora.pandorahack.module.ModuleManager;
import me.pandora.pandorahack.util.CapeUtils;
import me.pandora.pandorahack.util.ConfigUtils;
import me.pandora.pandorahack.friends.Friends;
import me.pandora.pandorahack.util.TpsUtils;
import me.pandora.pandorahack.util.font.CFontRenderer;
import me.pandora.pandorahack.waypoint.WaypointManager;
import me.zero.alpine.EventBus;
import me.zero.alpine.EventManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

import java.awt.*;

@Mod(modid = PandoraMod.MODID, name = PandoraMod.FORGENAME, version = PandoraMod.MODVER, clientSideOnly = true)
public class PandoraMod {
    public static final String MODID = "pandora";
    public static String MODNAME = "PandoraHack+";
    public static final String MODVER = "2.1.1";
    public static final String FORGENAME = "PandoraHack";

    public static final Logger log = LogManager.getLogger(MODNAME);
    public ClickGUI clickGui;
    public SettingsManager settingsManager;
    public Friends friends;
    public ModuleManager moduleManager;
    public static ModuleManager moduleManger;
    public ConfigUtils configUtils;
    public CapeUtils capeUtils;
    public MacroManager macroManager;
    EventProcessor eventProcessor;
    public WaypointManager waypointManager;
    public static CFontRenderer fontRenderer;
    public static Enemies enemies;

    public static final EventBus EVENT_BUS = new EventManager();

    @Mod.Instance
    private static PandoraMod INSTANCE;

    public PandoraMod(){
        INSTANCE = this;
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event){
        //log.info("PreInitialization complete!\n");

    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event){
        eventProcessor = new EventProcessor();
        eventProcessor.init();
        fontRenderer = new CFontRenderer(new Font("Arial", Font.PLAIN, 20), true, false);
        TpsUtils tpsUtils = new TpsUtils();

        settingsManager = new SettingsManager();
        log.info("Settings initialized!");

        friends = new Friends();
        enemies = new Enemies();
        log.info("Friends and enemies initialized!");

        moduleManager = new ModuleManager();
        log.info("Modules initialized!");

        clickGui = new ClickGUI();
        HudComponentManager hudComponentManager = new HudComponentManager(0, 0, clickGui);
        log.info("ClickGUI initialized!");

        macroManager = new MacroManager();
        log.info("Macros initialized!");

        configUtils = new ConfigUtils();
        Runtime.getRuntime().addShutdownHook(new ShutDownHookerino());
        log.info("Config loaded!");

        CommandManager.initCommands();
        log.info("Commands initialized!");

        waypointManager = new WaypointManager();
        log.info("Waypoints initialized!");

        log.info("Initialization complete!\n");
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event){
        Display.setTitle(MODNAME + " " + MODVER);

        capeUtils = new CapeUtils();
        log.info("Capes initialised!");

        //WelcomeWindow ww = new WelcomeWindow();
        //ww.setVisible(false);
        log.info("PostInitialization complete!\n");
    }

    public static PandoraMod getInstance(){
        return INSTANCE;
    }

}
