package me.pandora.pandorahack.module.modules.movement;

import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.module.Module;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.client.event.InputUpdateEvent;

public class Anchor extends Module {
    public Anchor() {
        super("Anchor", Category.MOVEMENT, "Cancels player motions to get in a hole");
    }

    private final BlockPos[] surroundOffset = {
            new BlockPos(0, -1, 0), // down
            new BlockPos(0, 0, -1), // north
            new BlockPos(1, 0, 0), // east
            new BlockPos(0, 0, 1), // south
            new BlockPos(-1, 0, 0) // west
    };

    @Override
    public void onUpdate() {
        for (int i=0;i<2;i++) {
            BlockPos pos = mc.player.getPosition().subtract(new Vec3i(0, i+1, 0));
            boolean isSafe = true;
            for (BlockPos offset : surroundOffset) {
                Block block = mc.world.getBlockState(pos.add(offset)).getBlock();
                if (block != Blocks.BEDROCK && block != Blocks.OBSIDIAN && block != Blocks.ENDER_CHEST && block != Blocks.ANVIL) {
                    isSafe = false;
                    break;
                }
            }
            if (isSafe) {
                mc.player.motionY--;
                mc.player.motionX = 0;
                mc.player.motionZ = 0;
                break;
            }
        }
    }

    public void onEnable(){
        PandoraMod.EVENT_BUS.subscribe(this);
    }

    public void onDisable(){
        PandoraMod.EVENT_BUS.unsubscribe(this);
    }
}