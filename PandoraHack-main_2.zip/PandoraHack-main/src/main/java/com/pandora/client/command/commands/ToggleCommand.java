package com.pandora.client.command.commands;

import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.command.Command;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;

/**
 * @Author Hoosiers on 11/05/2020
 */

public class ToggleCommand extends Command {

    public ToggleCommand(){
        super("Toggle");

        setCommandSyntax(Command.getCommandPrefix() + "toggle [module]");
        setCommandAlias(new String[]{
                "toggle", "t", "enable", "disable"
        });
    }

    public void onCommand(String command, String[] message) throws Exception{
        String main = message[0];

        for (Module module : ModuleManager.getModules()){
            if (module.getName().equalsIgnoreCase(main) && !module.isEnabled()){
                module.enable();
                MessageBus.sendClientPrefixMessage("Module " + module.getName() + " set to: ENABLED!");
            }
            else if (module.getName().equalsIgnoreCase(main) && module.isEnabled()){
                module.disable();
                MessageBus.sendClientPrefixMessage("Module " + module.getName() + " set to: DISABLED!");
            }
        }

        if (main == null || ModuleManager.getModuleByName(main) == null){
            MessageBus.sendClientPrefixMessage(this.getCommandSyntax());
        }
    }
}