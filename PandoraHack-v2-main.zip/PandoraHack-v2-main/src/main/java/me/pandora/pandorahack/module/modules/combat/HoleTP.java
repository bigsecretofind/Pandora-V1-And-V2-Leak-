package me.pandora.pandorahack.module.modules.combat;

import me.pandora.pandorahack.module.Module;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.Vec3i;

public class HoleTP extends Module {
    public HoleTP() {
        super("HoleTP", Category.COMBAT, "Gets you into holes faster");
    }
    public void onUpdate() {
        if (mc.player.onGround &&
            !mc.world.getBlockState(mc.player.getPosition()).getBlock().equals(Blocks.WATER) &&
            !mc.world.getBlockState(mc.player.getPosition()).getBlock().equals(Blocks.FLOWING_WATER) &&
            !mc.world.getBlockState(mc.player.getPosition()).getBlock().equals(Blocks.LAVA) &&
            !mc.world.getBlockState(mc.player.getPosition()).getBlock().equals(Blocks.FLOWING_LAVA) &&
            !mc.world.getBlockState(mc.player.getPosition().subtract(new Vec3i(0,1,0))).getBlock().equals(Blocks.WATER) &&
            !mc.world.getBlockState(mc.player.getPosition().subtract(new Vec3i(0,1,0))).getBlock().equals(Blocks.FLOWING_WATER) &&
            !mc.world.getBlockState(mc.player.getPosition().subtract(new Vec3i(0,1,0))).getBlock().equals(Blocks.LAVA) &&
            !mc.world.getBlockState(mc.player.getPosition().subtract(new Vec3i(0,1,0))).getBlock().equals(Blocks.FLOWING_LAVA))
            --mc.player.motionY;
    }
}