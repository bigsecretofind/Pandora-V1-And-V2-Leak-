package me.pandora.pandorahack.module.modules.render;

import de.Hero.settings.Setting;
import me.pandora.pandorahack.PandoraMod;
import me.pandora.pandorahack.event.events.RenderEvent;
import me.pandora.pandorahack.module.Module;
import me.pandora.pandorahack.util.PandoraTessellator;
import me.pandora.pandorahack.util.Rainbow;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

import java.awt.*;

public class BlockHighlight extends Module {
    public BlockHighlight() {
        super("BlockHighlight", Category.RENDER, "Highlights the block you're looking at");
    }

    Setting r;
    Setting g;
    Setting b;
    Setting a;
    Setting w;
    Setting rainbow;

    public void setup(){
        r = new Setting("Red", this, 255, 0, 255, true, "BlockHighlightRed");
        PandoraMod.getInstance().settingsManager.rSetting(r);
        g = new Setting("Green", this, 255, 0, 255, true, "BlockHighlightGreen");
        PandoraMod.getInstance().settingsManager.rSetting(g);
        b = new Setting("Blue", this, 255, 0, 255, true, "BlockHighlightBlue");
        PandoraMod.getInstance().settingsManager.rSetting(b);
        a = new Setting("Alpha", this, 255, 0, 255, true, "BlockHighlightAlpha");
        PandoraMod.getInstance().settingsManager.rSetting(a);
        w = new Setting("Width", this, 1, 1, 10, true, "BlockHighlightWidth");
        PandoraMod.getInstance().settingsManager.rSetting(w);
        PandoraMod.getInstance().settingsManager.rSetting(rainbow = new Setting("Rainbow", this, false, "BlockHighlightRainbow"));
    }

    public void onWorldRender(RenderEvent event){
        RayTraceResult ray = mc.objectMouseOver;
        AxisAlignedBB bb;
        BlockPos pos;
        Color c;
        Color color = Rainbow.getColor();
        if(rainbow.getValBoolean())
            c = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)a.getValDouble());
        else
            c = new Color((int)r.getValDouble(), (int)g.getValDouble(), (int)b.getValDouble(), (int)a.getValDouble());
        if(ray != null && ray.typeOfHit == RayTraceResult.Type.BLOCK){
            pos = ray.getBlockPos();
            bb = mc.world.getBlockState(pos).getSelectedBoundingBox(mc.world, pos);
            if(bb != null && pos != null && mc.world.getBlockState(pos).getMaterial() != Material.AIR){
                PandoraTessellator.prepareGL();
                PandoraTessellator.drawBoundingBox(bb, (int)w.getValDouble(), c.getRGB());
                PandoraTessellator.releaseGL();
            }
        }
    }
}
