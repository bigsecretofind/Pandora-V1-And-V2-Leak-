package com.pandora.client.command.commands;

import com.pandora.api.util.misc.MessageBus;
import com.pandora.client.command.Command;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;
import com.pandora.client.module.modules.hud.HUDModule;

public class FixHUDCommand extends Command {
	public FixHUDCommand() {
		super("FixHUD");
		setCommandSyntax(Command.getCommandPrefix() + "fixhud");
        setCommandAlias(new String[]{
                "fixhud", "hud", "resethud"
        });
	}

	@Override
	public void onCommand(String command, String[] message) throws Exception {
		for (Module module: ModuleManager.getModules()) {
			if (module instanceof HUDModule) {
				((HUDModule)module).resetPosition();
			}
		}
        MessageBus.sendClientPrefixMessage("HUD positions reset!");
	}

}
