package me.pandora.pandorahack.module.modules.movement;

import me.pandora.pandorahack.module.Module;


public class Jesus extends Module {
    public Jesus() {
        super("Jesus", Category.MOVEMENT, "Walk on water, changing water to wine not implemented yet");
    }

    public void onUpdate(){
    }
}
