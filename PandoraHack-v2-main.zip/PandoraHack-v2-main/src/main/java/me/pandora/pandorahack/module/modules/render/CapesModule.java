package me.pandora.pandorahack.module.modules.render;

import me.pandora.pandorahack.module.Module;

public class CapesModule extends Module {
    public CapesModule() {
        super("Capes", Category.RENDER);
        setEnabled(true);
        setDrawn(false);
    }
}
