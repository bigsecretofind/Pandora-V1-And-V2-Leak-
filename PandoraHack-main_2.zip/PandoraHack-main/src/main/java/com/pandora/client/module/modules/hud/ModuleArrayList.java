package com.pandora.client.module.modules.hud;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.pandora.api.settings.Setting;
import com.pandora.api.util.render.PandoraColor;
import com.pandora.client.PandoraMod;
import com.pandora.client.module.Module;
import com.pandora.client.module.ModuleManager;
import com.mojang.realmsclient.gui.ChatFormatting;

// PanelStudio rewrite by lukflug
public class ModuleArrayList extends ListModule {
    private static Setting.Boolean sortUp;
    private static Setting.Boolean sortRight;
    private static Setting.ColorSetting color;
	private static ModuleList list=new ModuleList();

    public ModuleArrayList(){
    	super(new ListModule.ListComponent("ArrayList",new Point(0,200),list),new Point(0,200));
    }

    public void setup(){
        sortUp = registerBoolean("Sort Up", "SortUp", true);
        sortRight = registerBoolean("Sort Right", "SortRight", false);
        color = registerColor("Color", "Color", new PandoraColor(255, 0, 0, 255));
    }

    public void onRender(){
    	list.activeModules.clear();
    	for (Module module: ModuleManager.getModules()) {
    		if (module.isEnabled() && module.isDrawn()) list.activeModules.add(module);
    	}
    	list.activeModules.sort(Comparator.comparing(module -> -PandoraMod.getInstance().clickGUI.getFontWidth(module.getName()+ChatFormatting.GRAY+" "+module.getHudInfo())));
    }
    

    private static class ModuleList implements ListModule.HUDList {
		public List<Module> activeModules=new ArrayList<Module>();
		
		@Override
		public int getSize() {
			return activeModules.size();
		}
	
		@Override
		public String getItem(int index) {
			Module module=activeModules.get(index);
			return module.getName()+ChatFormatting.GRAY+" "+module.getHudInfo();
		}
	
		@Override
		public Color getItemColor(int index) {
			PandoraColor c=color.getValue();
			return Color.getHSBColor(c.getHue()+(color.getRainbow()?.02f*index:0),c.getSaturation(),c.getBrightness());
		}

		@Override
		public boolean sortUp() {
			return sortUp.isOn();
		}

		@Override
		public boolean sortRight() {
			return sortRight.isOn();
		}
	}
}